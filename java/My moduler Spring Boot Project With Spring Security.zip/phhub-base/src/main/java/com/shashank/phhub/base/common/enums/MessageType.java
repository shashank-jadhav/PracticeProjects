

package com.shashank.phhub.base.common.enums;


public enum MessageType {
	
	TEXT,
	IMAGE,
	VIDEO,
	OTHER;

}
