

package com.shashank.phhub.base.common.enums;

public enum WorkOrderStatus {

	ACTIVE,
	PENDING_CANCELLATION,
	CANCELLED,
	COMPLETED;
}
