

package com.shashank.phhub.base.common.enums;

public enum UserSex {
	
	MALE, FEMALE;

}
