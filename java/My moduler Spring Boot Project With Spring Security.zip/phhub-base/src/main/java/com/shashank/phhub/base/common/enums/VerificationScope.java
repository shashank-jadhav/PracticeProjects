

package com.shashank.phhub.base.common.enums;

public enum VerificationScope {

	ACCOUNT_VERIFICATION_EMAIL, ACCOUNT_VERIFICATION_MOBILE, FORGOT_PASSWORD;

}
