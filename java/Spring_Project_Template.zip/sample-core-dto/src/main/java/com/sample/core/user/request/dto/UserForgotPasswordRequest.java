package com.sample.core.user.request.dto;



import java.io.Serializable;

import org.hibernate.validator.constraints.NotBlank;

import com.sample.base.common.utils.GsonProvider;

public class UserForgotPasswordRequest implements Serializable {

	private static final long serialVersionUID = 1L;

	@NotBlank
	private String username;

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	@Override
	public String toString() {
		return GsonProvider.gsonDisplayAll.toJson(this);
	}

}
