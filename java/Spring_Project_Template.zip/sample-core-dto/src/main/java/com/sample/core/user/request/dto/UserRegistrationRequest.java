package com.sample.core.user.request.dto;

import java.io.Serializable;

import org.hibernate.validator.constraints.NotBlank;

import com.google.gson.annotations.Expose;
import com.sample.base.common.utils.GsonProvider;

public class UserRegistrationRequest implements Serializable {

	private static final long serialVersionUID = 6616336990034342166L;

	@Expose
	@NotBlank
	private String username;

	@NotBlank
	private String password;

	private String authProvider;

	private String emailAddress;

	private String role;

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getEmailAddress() {
		return emailAddress;
	}

	public void setEmailAddress(String emailAddress) {
		this.emailAddress = emailAddress;
	}

	public String getRole() {
		return role;
	}

	public void setRole(String role) {
		this.role = role;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getAuthProvider() {
		return authProvider;
	}

	public void setAuthProvider(String authProvider) {
		this.authProvider = authProvider;
	}

	@Override
	public String toString() {
		return GsonProvider.gsonDisplayExposed.toJson(this);
	}

}
