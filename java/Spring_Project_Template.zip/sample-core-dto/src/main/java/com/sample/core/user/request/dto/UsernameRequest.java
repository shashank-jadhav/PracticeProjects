package com.sample.core.user.request.dto;

import java.io.Serializable;

import org.hibernate.validator.constraints.NotBlank;

import com.google.gson.annotations.Expose;
import com.sample.base.common.utils.GsonProvider;

public class UsernameRequest implements Serializable {

	private static final long serialVersionUID = 6616336990034342166L;

	@Expose
	@NotBlank
	private String emailAddress;

	public String getEmailAddress() {
		return emailAddress;
	}

	public void setEmailAddress(String emailAddress) {
		this.emailAddress = emailAddress;
	}

	@Override
	public String toString() {
		return GsonProvider.gsonDisplayExposed.toJson(this);
	}

}
