package com.sample.common.jaxrs.impl;


import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.sample.common.jaxrs.CommonAuthJaxrs;

public class CommonAuthJaxrsImpl implements CommonAuthJaxrs {

	Logger logger = LoggerFactory.getLogger(CommonAuthJaxrsImpl.class);

	
}
