package com.sample.jaxrs.user;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;
import javax.ws.rs.Consumes;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import com.sample.core.user.request.dto.UserForgotPasswordRequest;
import com.sample.core.user.request.dto.UserRegistrationRequest;
import com.sample.core.user.request.dto.UsernameRequest;

@Path("tp/user/p")
public interface UserJaxrs {

	/**
	 * Used to reset password
	 * 
	 * @param req
	 * @return
	 */
	@Path("forgot-pwd")
	@PUT
	@Consumes(value = { MediaType.APPLICATION_JSON })
	@Produces(value = { MediaType.APPLICATION_JSON })
	Response userForgotPassword(@Valid UserForgotPasswordRequest req);

	/**
	 * Save new user details
	 * 
	 * @param req
	 * @param request
	 * @return
	 */
	@Path("register-user")
	@POST
	@Consumes(value = { MediaType.APPLICATION_JSON })
	@Produces(value = { MediaType.APPLICATION_JSON })
	Response registerNewUser(@Valid UserRegistrationRequest req, @Context HttpServletRequest request);

	/**
	 * get list of user name based on email address
	 * @param req
	 * @return
	 */
	@Path("list-of-username-by-email")
	@POST
	@Consumes(value = { MediaType.APPLICATION_JSON })
	@Produces(value = { MediaType.APPLICATION_JSON })
	Response getUsernameByEmail(@Valid UsernameRequest req);

	
}
