package com.sample.controller;



import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.sample.service.user.UserService;

@Controller
public class VerifyUserAccountController {

	@Autowired
	private UserService userService;

	
	@RequestMapping(value = "/activate", method = RequestMethod.GET)
	public ModelAndView verifyUserAccount(HttpServletRequest request) {

		ModelAndView model = new ModelAndView();

		Long userId = Long.parseLong(request.getParameter("ui"));
		String activationCode = request.getParameter("ac");

		String message = userService.verifyUserAccount(userId, activationCode);

		model.addObject("msg", message);

		model.setViewName("activated");
		return model;
	}

}