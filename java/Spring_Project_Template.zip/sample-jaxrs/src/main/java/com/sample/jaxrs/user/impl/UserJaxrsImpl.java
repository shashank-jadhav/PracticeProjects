package com.sample.jaxrs.user.impl;

import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import com.sample.core.user.request.dto.UserForgotPasswordRequest;
import com.sample.core.user.request.dto.UserRegistrationRequest;
import com.sample.core.user.request.dto.UsernameRequest;
import com.sample.jaxrs.user.UserJaxrs;
import com.sample.service.user.UserService;

public class UserJaxrsImpl implements UserJaxrs {

	Logger logger = LoggerFactory.getLogger(UserJaxrsImpl.class);

	@Autowired
	private UserService userService;

	@Override
	public Response userForgotPassword(UserForgotPasswordRequest req) {
		try {
			return Response.ok().entity(userService.userForgotPassword(req)).type(MediaType.APPLICATION_JSON).build();
		} catch (Throwable t) {
			t.printStackTrace();
			return Response.serverError().build();
		}
	}

	@Override
	public Response registerNewUser(UserRegistrationRequest req, HttpServletRequest request) {
		try {
			return Response.ok().entity(userService.registerNewUser(req, request)).type(MediaType.APPLICATION_JSON)
					.build();
		} catch (Throwable t) {
			t.printStackTrace();
			return Response.serverError().build();
		}
	}

	@Override
	public Response getUsernameByEmail(UsernameRequest req) {
		try {
			return Response.ok().entity(userService.findUserNameByEmail(req)).type(MediaType.APPLICATION_JSON).build();
		} catch (Throwable t) {
			t.printStackTrace();
			return Response.serverError().build();
		}
	}
}
