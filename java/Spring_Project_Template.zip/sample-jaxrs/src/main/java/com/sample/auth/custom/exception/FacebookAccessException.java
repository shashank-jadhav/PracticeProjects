package com.sample.auth.custom.exception;



import org.springframework.security.core.AuthenticationException;

public class FacebookAccessException extends AuthenticationException {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 2899938670308102773L;
	
	
	private static final String MESSAGE_FORMAT = "FacebookAccessException: '%s'";

	public FacebookAccessException(String msg) {
		super(String.format(MESSAGE_FORMAT, msg));
		
	}

	
}
