package com.sample.auth.custom.exception;



import org.springframework.security.core.AuthenticationException;

public class AuthenticationFacebookException extends AuthenticationException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 5289808352015408823L;
	
	private static final String MESSAGE_FORMAT = "AuthenticationFacebookException: '%s'";

	public AuthenticationFacebookException(String msg) {
		super(String.format(MESSAGE_FORMAT, msg));
		
	}

	
}
