package com.sample.common.jaxrs;



import javax.ws.rs.Path;


@Path("common/p/")
public interface CommonAuthJaxrs {



}
