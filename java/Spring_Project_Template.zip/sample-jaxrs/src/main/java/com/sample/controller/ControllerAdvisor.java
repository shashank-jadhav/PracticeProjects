package com.sample.controller;



import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.NoHandlerFoundException;

@ControllerAdvice
class ControllerAdvisor {

	private final Logger logger = LoggerFactory.getLogger(ControllerAdvisor.class);

	@ExceptionHandler(Exception.class)
	public ModelAndView handleException(Exception ex) {
		logger.info("|*|*| Inside ControllerAdvisor#handleException - Catching: " + ex.getClass().getSimpleName());
		ModelAndView model = new ModelAndView();
		model.setViewName("genericerror");
		return model;
	}
	
	@ExceptionHandler(NoHandlerFoundException.class)
	public ModelAndView handle404Exception(HttpServletRequest req,Exception ex) {
		logger.info("|*|*| Inside ControllerAdvisor#handle404Exception - Catching: " + ex.getClass().getSimpleName());
		ModelAndView model = new ModelAndView();
		model.setViewName("genericerror");
		return model;
	}
}
