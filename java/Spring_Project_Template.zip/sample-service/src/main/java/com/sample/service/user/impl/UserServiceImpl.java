package com.sample.service.user.impl;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.sample.base.common.enums.Errors;
import com.sample.base.common.enums.Results;
import com.sample.base.common.enums.VerificationScope;
import com.sample.base.common.utils.DateUtil;
import com.sample.base.security.domain.AccountStatus;
import com.sample.core.dao.user.UserDao;
import com.sample.core.dao.user.UserVerificationCodeDao;
import com.sample.core.dto.GenericResponse;
import com.sample.core.user.request.dto.UserForgotPasswordRequest;
import com.sample.core.user.request.dto.UserRegistrationRequest;
import com.sample.core.user.request.dto.UsernameRequest;
import com.sample.hib.config.UserVerificationCodePK;
import com.sample.hib.model.user.User;
import com.sample.hib.model.user.UserVerificationCode;
import com.sample.producer.user.UserEmailProducer;
import com.sample.service.user.UserService;

/**
 * Service for user operations
 * 
 * @author nworks [Sagar Tarle]
 *
 */
@Service
public class UserServiceImpl implements UserService {

	Logger logger = LoggerFactory.getLogger(UserServiceImpl.class);
	private MessageSource messageSource;
	private UserDao userDao;
	private UserEmailProducer userEmailProducer;
	private UserVerificationCodeDao userVerificationCodeDao;
	private UserServiceHelper uerServiceHelper;
	private BCryptPasswordEncoder bcryptPasswordEncoder;

	@Autowired
	public UserServiceImpl(MessageSource messageSource, UserDao userDao, UserEmailProducer userEmailProducer,
			UserVerificationCodeDao userVerificationCodeDao, UserServiceHelper uerServiceHelper,
			BCryptPasswordEncoder bcryptPasswordEncoder) {
		super();
		this.userDao = userDao;
		this.messageSource = messageSource;
		this.userEmailProducer = userEmailProducer;
		this.uerServiceHelper = uerServiceHelper;
		this.userVerificationCodeDao = userVerificationCodeDao;
		this.bcryptPasswordEncoder = bcryptPasswordEncoder;
	}

	@Override
	@Transactional(propagation = Propagation.REQUIRES_NEW)
	public User findUserByUserName(String userName) {

		logger.info("Inside UserServiceImpl#findUserByUserName() for userName: {}", userName);
		return userDao.findUserByUserName(userName);
	}

	@Override
	@Transactional(propagation = Propagation.REQUIRES_NEW)
	public String verifyUserAccount(Long userId, String activationCode) {

		UserVerificationCodePK pk = new UserVerificationCodePK(userId,
				VerificationScope.ACCOUNT_VERIFICATION_EMAIL.name());

		UserVerificationCode verificationCode = userVerificationCodeDao.findOne(pk);

		if (verificationCode != null
				&& verificationCode.getCodeExpirationMillis().longValue() < DateUtil.getCurrentMillis()) {
			return messageSource.getMessage("Errors.ActivationLinkExpire.message", null, null, null);
		} else if (verificationCode != null
				&& verificationCode.getCodeExpirationMillis().longValue() > DateUtil.getCurrentMillis()
				&& verificationCode.getVerificationCode().equals(activationCode)) {
			User user = userDao.findOne(userId);
			// activating user's account
			user.setAccountStatus(AccountStatus.ACTIVE.name());
			userDao.update(user);
			// deleting activation code from DB
			userVerificationCodeDao.delete(verificationCode);
			return messageSource.getMessage("Success.AccountActivated.message", null, null, null);
		} else {
			return messageSource.getMessage("Errors.ActivationLinkInvalid.message", null, null, null);
		}

	}

	@Override
	@Transactional(propagation = Propagation.REQUIRES_NEW)
	public GenericResponse userForgotPassword(UserForgotPasswordRequest req) {
		logger.info("inside userForgotPassword() for  req :: {} ", req);
		User user = userDao.findUserByUserName(req.getUsername());

		if (user == null) {
			return new GenericResponse.Builder().error(Errors.UserNotExist)
					.message(messageSource.getMessage("Errors.UserNotExist.message", null, null, null)).build();
		} else {
			// sending mail to user
			userEmailProducer.sendResetPwdEmail(user.getEmailAddress(), user.getUserName());
			return new GenericResponse.Builder().result(Results.PasswordResetSuccessfully)
					.message(messageSource.getMessage("Success.PasswordResetSuccessfully.message", null, null, null))
					.build();
		}
	}

	@Override
	@Transactional(propagation = Propagation.REQUIRES_NEW)
	public GenericResponse registerNewUser(UserRegistrationRequest req, HttpServletRequest request) {

		logger.info("Inside UserRegistrationServiceImpl#registerNewUser for req: {}", req);

		// Declaring activation code and userid
		Long userId = null;
		User user = userDao.findUserByUserName(req.getUsername());
		if (user != null) {
			if (user.getAccountStatus().equals(AccountStatus.ACTIVE.name())) {
				return new GenericResponse.Builder().error(Errors.UserAlreadyRegistered)
						.message(messageSource.getMessage("Errors.UserAlreadyRegistered.message", null, null, null))
						.build();
			} else if (user.getAccountStatus().equals(AccountStatus.PENDING_VERIFICATION.name())) {
				user.setPasswordHash(bcryptPasswordEncoder.encode(req.getPassword()));
				userDao.update(user);
				uerServiceHelper.sendActivationLink(user.getUserId(), user.getEmailAddress(), request);
			}
		} else {
			user = uerServiceHelper.getUserRegistrationRequest(req);
			userId = (Long) userDao.save(user);
			uerServiceHelper.sendActivationLink(userId, user.getEmailAddress(), request);
		}
		return new GenericResponse.Builder().result(Results.UserRegisteredSuccessfully)
				.message(messageSource.getMessage("Success.UserRegisteredSuccessfully.message", null, null, null))
				.build();

	}

	@Override
	@Transactional(propagation = Propagation.REQUIRES_NEW)
	public GenericResponse findUserNameByEmail(UsernameRequest req) {

		List<String> usernameList = userDao.findUserNameByEmail(req.getEmailAddress());

		if (usernameList.size() == 0) {
			return new GenericResponse.Builder().error(Errors.EmptyUsernameList)
					.message(messageSource.getMessage("Errors.EmptyUsernameList.message", null, null, null)).build();
		}
		userEmailProducer.sendUserNameEmail(req.getEmailAddress(), usernameList);

		return new GenericResponse.Builder().result(Results.TippingNameList)
				.message(messageSource.getMessage("Success.TippingName.message", null, null, null)).build();

	}

}
