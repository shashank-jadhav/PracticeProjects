package com.sample.service.user;

import javax.servlet.http.HttpServletRequest;

import com.sample.core.dto.GenericResponse;
import com.sample.core.user.request.dto.UserForgotPasswordRequest;
import com.sample.core.user.request.dto.UserRegistrationRequest;
import com.sample.core.user.request.dto.UsernameRequest;
import com.sample.hib.model.user.User;

public interface UserService {

	
	/**
	 * Find user by user name
	 * @param userName
	 * @return
	 */
	User findUserByUserName(String userName);

	/**
	 * Verify user account for login
	 * 
	 * @param userId
	 * @param activationCode
	 * @return
	 */
	String verifyUserAccount(Long userId, String activationCode);

	/**
	 * Reset password
	 * 
	 * @param req
	 * @return
	 */
	GenericResponse userForgotPassword(UserForgotPasswordRequest req);

	/**
	 * save new user registration details
	 * 
	 * @param req
	 * @param request
	 * @return
	 */
	GenericResponse registerNewUser(UserRegistrationRequest req, HttpServletRequest request);

	/**
	 * Get username list by email
	 * 
	 * @param request
	 * @return
	 */
	GenericResponse findUserNameByEmail(UsernameRequest request);

}
