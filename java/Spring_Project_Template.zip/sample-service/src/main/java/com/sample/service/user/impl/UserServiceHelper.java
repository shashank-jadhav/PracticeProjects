package com.sample.service.user.impl;

import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.ZonedDateTime;

import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Component;

import com.sample.base.common.enums.VerificationScope;
import com.sample.base.common.utils.ActivationCodeGenerator;
import com.sample.base.common.utils.Constants;
import com.sample.base.common.utils.DateUtil;
import com.sample.base.security.domain.AccountStatus;
import com.sample.base.security.domain.AuthProvider;
import com.sample.core.dao.user.UserVerificationCodeDao;
import com.sample.core.user.request.dto.UserRegistrationRequest;
import com.sample.hib.config.UserVerificationCodePK;
import com.sample.hib.model.user.User;
import com.sample.hib.model.user.UserVerificationCode;
import com.sample.producer.user.UserEmailProducer;

/**
 * Helper class for user service
 * 
 * @author nworks [Sagar Tarle]
 *
 */
@Component
public class UserServiceHelper {

	Logger logger = LoggerFactory.getLogger(UserServiceImpl.class);
	private BCryptPasswordEncoder bcryptPasswordEncoder;
	private MessageSource messageSource;
	private UserVerificationCodeDao userVerificationCodeDao;
	private UserEmailProducer userEmailProducer;

	@Autowired
	public UserServiceHelper(MessageSource messageSource, UserEmailProducer userEmailProducer,
			BCryptPasswordEncoder bcryptPasswordEncoder, UserVerificationCodeDao userVerificationCodeDao) {
		super();
		this.messageSource = messageSource;
		this.userEmailProducer = userEmailProducer;
		this.bcryptPasswordEncoder = bcryptPasswordEncoder;
		this.userVerificationCodeDao = userVerificationCodeDao;

	}

	/*************************** Public Methods ********************************/

	/**
	 * Fill user registration request
	 * 
	 * @param req
	 * @return
	 */
	public User getUserRegistrationRequest(UserRegistrationRequest req) {

		logger.info("Inside UserServiceHelper::getUserRegistrationRequest");
		User user = new User();
		user.setUserName(req.getUsername());
		user.setTippingName(req.getUsername());
		user.setEmailAddress(req.getEmailAddress());
		user.setRole(req.getRole());
		user.setPasswordHash(bcryptPasswordEncoder.encode(req.getPassword()));
		user.setAccountStatus(AccountStatus.PENDING_VERIFICATION.name());
		// user.setRole(Role.ROLE_NORMAL_USER.name());
		user.setAuthProvider(AuthProvider.AUP_APPLICATION.name());
		return user;
	}

	/**
	 * Get verificationCode code and send email activation link to user
	 * 
	 * @param userId
	 * @param emailId
	 * @param request
	 */
	public void sendActivationLink(Long userId, String emailId, HttpServletRequest request) {

		logger.info("Inside UserServiceHelper::sendActivationLink");

		String activationCode = ActivationCodeGenerator.generateCode();
		UserVerificationCodePK pk = new UserVerificationCodePK(userId,
				VerificationScope.ACCOUNT_VERIFICATION_EMAIL.name());
		UserVerificationCode verificationCode = userVerificationCodeDao.findOne(pk);

		if (verificationCode != null
				&& verificationCode.getCodeExpirationMillis().longValue() < DateUtil.getCurrentMillis()) {
			activationCode = ActivationCodeGenerator.generateCode();
		//	UserVerificationCodePK pk2= pk != verificationCode.getVCPK()?pk:null;
			 fillVerificationCodeDetails(verificationCode,pk, activationCode);
			userVerificationCodeDao.update(verificationCode);
		} else if (verificationCode != null
				&& verificationCode.getCodeExpirationMillis().longValue() > DateUtil.getCurrentMillis()) {
			activationCode = verificationCode.getVerificationCode();
		} else if (verificationCode == null) {
			activationCode = ActivationCodeGenerator.generateCode();
			verificationCode = new UserVerificationCode();
			fillVerificationCodeDetails(verificationCode,pk, activationCode);
			userVerificationCodeDao.save(verificationCode);
		}
		StringBuilder activationLink = createActivationLink(request, userId, activationCode);
		if (activationLink != null) {
			userEmailProducer.sendActivationLinkEmail(emailId, activationLink.toString());
		}
	}

	/************************* Private Methods ***********************************/

	/**
	 * Fill Verification_Code Details
	 * 
	 * @param pk
	 * @param activationCode
	 * @return
	 */
	private UserVerificationCode fillVerificationCodeDetails(UserVerificationCode verificationCode,UserVerificationCodePK pk, String activationCode) {

		logger.info("Inside UserServiceHelper::fillVerificationCodeDetails");

		LocalDateTime ldt = DateUtil.getLocalDateTime();
		ZonedDateTime zdt = DateUtil.getSystemDefaultZonedDateTime(ldt);
		LocalDateTime expldt = ldt.plusDays(
				Integer.parseInt(messageSource.getMessage("activationlink.expiration.days", null, null, null)));
		ZonedDateTime zexpdt = DateUtil.getSystemDefaultZonedDateTime(expldt);
		//UserVerificationCode verificationCode = new UserVerificationCode();

		// creating new activation code
		if (pk != null) {
			verificationCode.setVCPK(pk);
		}
		verificationCode.setCodeRequestTimezone(ZoneId.systemDefault().getId());
		verificationCode.setCodeRequestMillis(zdt.toInstant().toEpochMilli());
		verificationCode.setCodeRequestDateTime(ldt);
		verificationCode.setCodeExpirationTimezone(ZoneId.systemDefault().getId());
		verificationCode.setCodeExpirationDateTime(expldt);
		verificationCode.setCodeExpirationMillis(zexpdt.toInstant().toEpochMilli());
		verificationCode.setVerificationCode(activationCode);
		return verificationCode;
	}

	/**
	 * Create activation link
	 * 
	 * @param request
	 * @param userId
	 * @param activationCode
	 * @return
	 */
	private StringBuilder createActivationLink(HttpServletRequest request, long userId, String activationCode) {

		logger.info("Inside UserServiceHelper::createActivationLink");

		StringBuilder activationLink = new StringBuilder();
		activationLink.append(request.getScheme());
		activationLink.append(Constants.SCHEME_SEPARATOR);
		activationLink.append(request.getServerName());
		activationLink.append(Constants.COLON);
		activationLink.append(new Integer(request.getServerPort()).toString());
		activationLink.append(request.getContextPath());
		activationLink.append(Constants.FORWARDSLASH);
		activationLink.append("web");
		activationLink.append(Constants.FORWARDSLASH);
		activationLink.append("activate");
		activationLink.append("?ui=");
		activationLink.append(userId);
		activationLink.append("&ac=");
		activationLink.append(activationCode);

		return activationLink;

	}

}
