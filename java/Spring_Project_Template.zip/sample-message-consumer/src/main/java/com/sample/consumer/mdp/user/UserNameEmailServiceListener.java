package com.sample.consumer.mdp.user;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.jms.JMSException;
import javax.jms.MapMessage;
import javax.jms.Message;
import javax.jms.MessageListener;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.sample.base.common.utils.ActivemqConstants;
import com.sample.consumer.utils.EmailSender;

@Transactional(propagation = Propagation.REQUIRES_NEW)
public class UserNameEmailServiceListener implements MessageListener {

	Logger logger = LoggerFactory.getLogger(UserNameEmailServiceListener.class);

	@Autowired
	private EmailSender emailSender;
	@Autowired
	private MessageSource messageSource;

	@SuppressWarnings("unchecked")
	@Override
	public void onMessage(Message msg) {

		try {
			logger.info(
					"Inside UserTippingNameEmailServiceListener::onMessage for JMSMessageID = {}; MSDeliveryMode = {}; JMSRedelivered = {}; JMSQueue = {}.",
					msg.getJMSMessageID(), msg.getJMSDeliveryMode(), msg.getJMSRedelivered(),
					msg.getStringProperty(ActivemqConstants.KEY_REG_MSG_TYPE));
			if (msg instanceof MapMessage) {
				MapMessage mapMsg = (MapMessage) msg;

				String to_email = mapMsg.getStringProperty(ActivemqConstants.KEY_USER_EMAIL);
				List<String> userNames = (List<String>) mapMsg.getObjectProperty(ActivemqConstants.USER_NAME_FOR_RETRIVE);

				Map<String, Object> model = new HashMap<String, Object>();

				model.put("usernames", userNames);
				emailSender.sendMail(messageSource.getMessage("mail.username", null, null, null), to_email, "Tipping Name",
						model, "com/tpoint/consumer/utils/UserNameEmail.ftl");

			}
		} catch (JMSException ex) {
			logger.error("JMSException:", ex);
			throw new RuntimeException(ex);
		}
	}

}
