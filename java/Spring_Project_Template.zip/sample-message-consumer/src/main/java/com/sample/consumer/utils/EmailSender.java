package com.sample.consumer.utils;



import java.io.File;

import javax.mail.internet.MimeMessage;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.config.BeanDefinition;
import org.springframework.context.MessageSource;
import org.springframework.context.annotation.Scope;
import org.springframework.mail.MailException;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.mail.javamail.MimeMessagePreparator;
import org.springframework.stereotype.Service;
import org.springframework.ui.freemarker.FreeMarkerTemplateUtils;

import freemarker.template.Configuration;

@Service
@Scope(BeanDefinition.SCOPE_SINGLETON)
public class EmailSender {

	Logger logger = LoggerFactory.getLogger(EmailSender.class);

	@Autowired
	private JavaMailSender javaMailSender;
	@Autowired
	private JavaMailSender alternateJavaMailSender;
	@Autowired
	private Configuration freemarkerConfiguration;
	@Autowired
	private MessageSource messageSource;

	public EmailSender() {
	}

	public void sendMail(final String from, final String[] to, final String subject, final Object model,
			final String template, File file1) throws MailException {

		MimeMessagePreparator mimeMessagePreparator = new MimeMessagePreparator() {

			public void prepare(MimeMessage mimeMessage) throws Exception {
				MimeMessageHelper mimeMessageHelper = new MimeMessageHelper(mimeMessage, true);
				mimeMessageHelper.setFrom(from, messageSource.getMessage("mail.personal", null, "NoCard", null));
				mimeMessageHelper.setTo(to);
				mimeMessageHelper.setSubject(subject);
				mimeMessageHelper.addAttachment(file1.getName(), file1);

				String text = FreeMarkerTemplateUtils
						.processTemplateIntoString(freemarkerConfiguration.getTemplate(template, "UTF-8"), model);
				// boolean true is for html
				mimeMessageHelper.setText(text, true);
			}
		};

		try {
			logger.info("Attempting to send email via 1and1 now");
			javaMailSender.send(mimeMessagePreparator);
		} catch (Exception e) {
			logger.debug("MailException occured while sending the mail for ftl model:::{}::: MailException object::{}",
					model, e);
			try {
				logger.info("Attempting to send email via Gmail now");
				alternateJavaMailSender.send(mimeMessagePreparator);
			} catch (MailException ae) {
				logger.error(
						"MailException occured while sending the mail for ftl model:::{}::: MailException object::{}",
						model, ae);
				throw ae;
			}

		}
	}

	public void sendMail(final String from, final String to, final String subject, final Object model,
			final String template) throws MailException {

		MimeMessagePreparator mimeMessagePreparator = new MimeMessagePreparator() {

			public void prepare(MimeMessage mimeMessage) throws Exception {
				MimeMessageHelper mimeMessageHelper = new MimeMessageHelper(mimeMessage, true);
				mimeMessageHelper.setFrom(from);
				mimeMessageHelper.setTo(to);
				mimeMessageHelper.setSubject(subject);
				String text = FreeMarkerTemplateUtils
						.processTemplateIntoString(freemarkerConfiguration.getTemplate(template, "UTF-8"), model);
				// boolean true is for html
				mimeMessageHelper.setText(text, true);
			}
		};

		try {
			logger.info("Attempting to send email via 1and1 now");
			javaMailSender.send(mimeMessagePreparator);
		} catch (Exception e) {
			logger.debug("MailException occured while sending the mail for ftl model:::{}::: MailException object::{}",
					model, e);
			try {
				logger.info("Attempting to send email via Gmail now");
				alternateJavaMailSender.send(mimeMessagePreparator);
			} catch (MailException ae) {
				logger.error(
						"MailException occured while sending the mail for ftl model:::{}::: MailException object::{}",
						model, ae);
				throw ae;
			}

		}
	}

}
