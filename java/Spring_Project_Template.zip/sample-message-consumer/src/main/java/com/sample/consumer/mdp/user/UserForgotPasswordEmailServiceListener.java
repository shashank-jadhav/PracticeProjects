package com.sample.consumer.mdp.user;

import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.util.HashMap;
import java.util.Map;

import javax.jms.JMSException;
import javax.jms.MapMessage;
import javax.jms.Message;
import javax.jms.MessageListener;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.sample.base.common.utils.ActivemqConstants;
import com.sample.base.common.utils.DateUtil;
import com.sample.base.common.utils.RandomPasswordGenerator;
import com.sample.consumer.utils.EmailSender;
import com.sample.core.dao.user.UserDao;
import com.sample.hib.model.user.User;

@Transactional(propagation = Propagation.REQUIRES_NEW)
public class UserForgotPasswordEmailServiceListener implements MessageListener {

	Logger logger = LoggerFactory.getLogger(UserForgotPasswordEmailServiceListener.class);

	@Autowired
	private EmailSender emailSender;
	@Autowired
	private UserDao userDao;
	@Autowired
	private BCryptPasswordEncoder bCryptPasswordEncoder;
	@Autowired
	private MessageSource messageSource;

	@Override
	public void onMessage(Message msg) {

		try {
			logger.info(
					"Inside UserForgotPasswordEmailServiceListener::onMessage for JMSMessageID = {}; MSDeliveryMode = {}; JMSRedelivered = {}; JMSQueue = {}.",
					msg.getJMSMessageID(), msg.getJMSDeliveryMode(), msg.getJMSRedelivered(),
					msg.getStringProperty(ActivemqConstants.KEY_REG_MSG_TYPE));
			if (msg instanceof MapMessage) {
				MapMessage mapMsg = (MapMessage) msg;

				String email = mapMsg.getStringProperty(ActivemqConstants.KEY_USER_EMAIL);
				String userName = mapMsg.getStringProperty(ActivemqConstants.USER_NAME);

				// time
				LocalDateTime ldt = DateUtil.getLocalDateTime();
				ZonedDateTime zdt = DateUtil.getSystemDefaultZonedDateTime(ldt);

				logger.info("Inside UserDao ::findUserByUserName for userName :{}", userName);
				User user = userDao.findUserByUserName(userName);

				String newPass = RandomPasswordGenerator.generatePassword();
				user.setPasswordHash(bCryptPasswordEncoder.encode(newPass));
				// user.setPasswordChangeDatetime(ldt);
				user.setPasswordChangeMillis(zdt.toInstant().toEpochMilli());
				user.setPasswordChangeTimezone(ZoneId.systemDefault().getId());

				userDao.update(user);

				Map<String, String> model = new HashMap<String, String>();

				model.put("password", newPass);
				emailSender.sendMail(messageSource.getMessage("mail.username", null, null, null), email,
						"Forgot password", model, "com/tpoint/consumer/utils/ForgotPasswordEmail.ftl");

			}
		} catch (JMSException ex) {
			logger.error("JMSException:", ex);
			throw new RuntimeException(ex);
		}
	}

}
