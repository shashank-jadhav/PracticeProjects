package com.sample.consumer.errorhandler;



import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.util.ErrorHandler;

public class EmailServiceListenerErrorHandler implements ErrorHandler {

	public EmailServiceListenerErrorHandler() {
	}

	Logger logger = LoggerFactory.getLogger(EmailServiceListenerErrorHandler.class);

	@Override
	public void handleError(Throwable t) {
		logger.error("Error in EmailServiceListenerErrorHandler: ", t);

	}
}
