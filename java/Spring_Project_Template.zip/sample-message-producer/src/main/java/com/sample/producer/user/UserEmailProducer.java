package com.sample.producer.user;

import java.util.List;

import javax.jms.JMSException;
import javax.jms.MapMessage;
import javax.jms.Message;
import javax.jms.Session;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jms.JmsException;
import org.springframework.jms.core.JmsTemplate;
import org.springframework.jms.core.MessageCreator;
import org.springframework.stereotype.Component;

import com.sample.base.common.utils.ActivemqConstants;

@Component
public class UserEmailProducer {
	public UserEmailProducer() {

	}

	Logger logger = LoggerFactory.getLogger(UserEmailProducer.class);
	@Autowired
	private JmsTemplate queueUserMessageServiceTemplate;

	/**
	 * Send Activation link amail
	 * 
	 * @param email
	 * @param activationLink
	 * @throws JmsException
	 */
	public void sendActivationLinkEmail(String email, String activationLink) throws JmsException {

		logger.info("Inside UserEmailProducer::sendActivationLinkEmail");
		// Publishing the message to the JMS queue.
		queueUserMessageServiceTemplate.send(new MessageCreator() {
			public Message createMessage(Session session) throws JMSException {
				MapMessage mapMessage = session.createMapMessage();
				mapMessage.setStringProperty(ActivemqConstants.KEY_USER_EMAIL, email);
				mapMessage.setStringProperty(ActivemqConstants.KEY_ACTIVATION_LINK, activationLink);
				mapMessage.setStringProperty(ActivemqConstants.KEY_REG_MSG_TYPE,
						ActivemqConstants.VALUE_SEND_USER_ACCOUNT_VERIFICATION_EMAIL);
				return mapMessage;
			}
		});
	}

	/**
	 * Send reset password email
	 * 
	 * @param email
	 * @param username
	 * @throws JmsException
	 */
	public void sendResetPwdEmail(String email, String username) throws JmsException {

		logger.info("Inside UserEmailProducer::sendResetPwdEmail");
		// Publishing the message to the JMS queue.
		queueUserMessageServiceTemplate.send(new MessageCreator() {
			public Message createMessage(Session session) throws JMSException {
				MapMessage mapMessage = session.createMapMessage();
				mapMessage.setStringProperty(ActivemqConstants.KEY_USER_EMAIL, email);
				mapMessage.setStringProperty(ActivemqConstants.USER_NAME, username);
				mapMessage.setStringProperty(ActivemqConstants.KEY_REG_MSG_TYPE,
						ActivemqConstants.VALUE_SEND_FORGOT_PWD_EMAIL);
				return mapMessage;
			}
		});
	}

	/**
	 * Used to send user name using mail.
	 * 
	 * @param email
	 * @param userName
	 * @throws JmsException
	 */
	public void sendUserNameEmail(String email, List<String> userName) throws JmsException {

		logger.info("Inside UserEmailProducer::sendUserNameEmail");
		// Publishing the message to the JMS queue.
		queueUserMessageServiceTemplate.send(new MessageCreator() {
			public Message createMessage(Session session) throws JMSException {
				MapMessage mapMessage = session.createMapMessage();
				mapMessage.setStringProperty(ActivemqConstants.KEY_USER_EMAIL, email);
				mapMessage.setObjectProperty(ActivemqConstants.USER_NAME_FOR_RETRIVE, userName);
				mapMessage.setStringProperty(ActivemqConstants.KEY_REG_MSG_TYPE,
						ActivemqConstants.VALUE_SEND_USER_NAME_EMAIL);
				return mapMessage;
			}
		});
	}

}
