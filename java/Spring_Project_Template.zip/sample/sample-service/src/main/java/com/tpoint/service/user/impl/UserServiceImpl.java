package com.tpoint.service.user.impl;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.tpoint.core.dao.user.UserDao;
import com.tpoint.hib.model.user.User;
import com.tpoint.service.user.UserService;

@Service
public class UserServiceImpl implements UserService {

	Logger logger = LoggerFactory.getLogger(UserServiceImpl.class);

	private UserDao userDao;

	@Autowired
	public UserServiceImpl(UserDao userDao) {
		super();
		this.userDao = userDao;
	}

	@Override
	@Transactional(propagation = Propagation.REQUIRES_NEW)
	public User findUserByUserName(String userName) {
		
		
		logger.info("Inside UserServiceImpl#findUserByUserName() for userName: {}", userName);
		return userDao.findUserByUserName(userName);
	}

}
