package com.tpoint.service.user;

import com.tpoint.hib.model.user.User;

public interface UserService {

	User findUserByUserName(String userName);
}
