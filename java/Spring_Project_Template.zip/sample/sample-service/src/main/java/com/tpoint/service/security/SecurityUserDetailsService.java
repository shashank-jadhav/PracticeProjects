package com.tpoint.service.security;



import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.tpoint.base.security.domain.SecurityUserDetails;
import com.tpoint.core.dao.user.UserDao;
import com.tpoint.hib.model.user.User;

public class SecurityUserDetailsService implements UserDetailsService {

	Logger logger = LoggerFactory.getLogger(SecurityUserDetailsService.class);
	
	@Autowired
	private UserDao userDao;
	
	public SecurityUserDetailsService() {}
    
	@Transactional(readOnly=true,propagation=Propagation.REQUIRES_NEW)
	public UserDetails loadUserByUsername(String username)
			throws UsernameNotFoundException {
 
		logger.debug("userDao:{}",userDao);
		User user = userDao.findUserByUserName(username);
		if (user == null) {
			throw new UsernameNotFoundException("No user found with username: " + username);
		}

		SecurityUserDetails principal = SecurityUserDetails.getBuilder()
		.accountNotBanned(!user.isBanned())
		.authProvider(user.getAuthProvider())
		.password(user.getPasswordHash())
		.role(user.getRole())
		.activated(true)
		.userId(user.getUserId())
		.userName(user.getUserName())
		.build();
		
		return principal;
	}

}
