package com.tpoint.base.common.utils;



/**
 * -----------------------------------------------------------------------------
 * <br>
 * <b>Purpose:</b>
 * <p>
 * The purpose of this class is to define widely used constants. Only add
 * constants that are to be used across the project spectrum. All members of
 * this class are immutable. To avoid callers from instantiating the class, a
 * private constructor is used to enforce that policy.
 * </p>
 * -----------------------------------------------------------------------------
 * <br>
 * <b>Implementation:</b>
 * <p>
 * The caller must refer to these constants using static references, such as
 * </p>
 * <blockquote><code>Constants.SUCCESS, Consts.FAILURE,</code> and so on.<br>
 * </blockquote>
 * <p>
 * The members of this class qualify for a static import such as
 * </p>
 * <blockquote><code>import static {package-name}.Constants.SUCCESS;</code><br>
 * </blockquote>
 * 
 * -----------------------------------------------------------------------------
 * 
 * @author Saurabh Pawar
 */
public final class Constants {

	/**
	 * Private Constructor to avoid other classes from instantiating this class.
	 */
	private Constants() {
		throw new UnsupportedOperationException();
	}

	// Constants-----------------------------------------------------------------------------
	/**
	 * Useful for {@link String} operations, which return an index of
	 * <tt>-1</tt> when an item is not found.
	 */
	public static final int NOT_FOUND = -1;

	/**
	 * System property - <tt>line.separator</tt>
	 */
	public static final String LINE_SEPARATOR = System.getProperty("line.separator");

	/**
	 * System property - <tt>file.separator</tt>
	 */
	public static final String FILE_SEPARATOR = System.getProperty("file.separator");

	/**
	 * System property - <tt>path.separator</tt>
	 */
	public static final String PATH_SEPARATOR = System.getProperty("path.separator");

	/**
	 * Scheme separator used in links http://
	 */
	public static final String SCHEME_SEPARATOR = "://";

	/**
	 * Colon
	 */
	public static final String COLON = ":";

	/**
	 * Dot
	 */
	public static final String DOT = ".";

	/**
	 * Comma
	 */
	public static final String COMMA = ",";

	/**
	 * Question Mark
	 */
	public static final String QUESTION_MARK = "?";

	/**
	 * An Empty String
	 */
	public static final String EMPTY_STRING = "";

	/**
	 * Insert a single space at this point.
	 */
	public static final String WHITESPACE = " ";

	/**
	 * Insert a period/dot ( . ) at this point.
	 */
	public static final String PERIOD = ".";

	/**
	 * Sign used to join words.
	 */
	public static final String HYPHEN = "-";

	// Escape
	// Sequences-----------------------------------------------------------------------------
	/**
	 * Insert a tab in the text at this point.
	 */
	public static final String TAB = "\t";

	/**
	 * Insert a backspace in the text at this point.
	 */
	public static final String BACKSPACE = "\t";

	/**
	 * Insert a newline in the text at this point.
	 */
	public static final String NEW_LINE = "\n";

	/**
	 * Insert a single quote at this point.
	 */
	public static final String SINGLE_QUOTE = "\'";

	/**
	 * Insert a double quote at this point.
	 */
	public static final String DOUBLE_QUOTE = "\"";

	/**
	 * Insert a backslash character in the text at this point.
	 */
	public static final String BACKSLASH = "\\";

	/**
	 * Insert a forward slash character in the text at this point.
	 */
	public static final String FORWARDSLASH = "/";

	/**
	 * Fundamental Success string.
	 */
	public static final String SUCCESS = "success";

	/**
	 * Fundamental Failure string.
	 */
	public static final String FAILURE = "failure";

	/**
	 * Start of Heading.
	 */
	public static final char SOH = '\u0001';

	/**
	 * FCM priority const.
	 */
	public static final String HIGH = "high";
	
	

}