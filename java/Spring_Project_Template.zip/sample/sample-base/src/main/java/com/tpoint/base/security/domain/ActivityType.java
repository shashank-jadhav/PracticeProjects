package com.tpoint.base.security.domain;


public enum ActivityType {
	EMAIL_ADDRESS_VERIFICATION, FORGOT_PASSWORD, MOBILE_NUMBER_VERIFICATION;

}
