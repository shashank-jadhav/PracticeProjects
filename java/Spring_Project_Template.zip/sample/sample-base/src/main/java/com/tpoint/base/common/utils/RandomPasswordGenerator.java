package com.tpoint.base.common.utils;



import java.util.Random;

/**
 * Password is generated in an insecure way, but its supposed to be changed by
 * the user immediately, so the security risk is lower. The number of users who
 * are going to use are low, so its not too big of a concern. Internal
 * application so the password is made easier to remember while entering the
 * first time.
 */
public class RandomPasswordGenerator {

	private static String colorWords[] = { "Black", "White", "Orange", "Pink", "Green", "Violet", "Blue", "Amber",
			"Aqua", "Yellow", "Red", "Purple", "Crimson", "Lavender", "Indigo", "Almond", "Gold", "Silver", "Brown",
			"Rose", "Bronze", "Ruby", "Lime", "Coral", "Azure", "Satin", "Mauve" };

	private static String shapeWords[] = { "Circle", "Oval", "Square", "Triangle", "Diamond", "Hexagon", "Pentagon",
			"Polygon", "Star", "Ellipse", "Line", "Kite", "Curve", "Cone" };

	private static String fruitWords[] = { "Apple", "Orange", "Banana", "Grape", "Lemon", "Pear", "Mango", "Cherry",
			"Peach", "Apricot", "Apricot", "Papaya", "Avocado", "Coconut", "Olive", "Plum", "Raspberry", "Huckleberry",
			"Gooseberry", "Olive", "Cranberry", "Mulberry", "Passionfruit" };

	private static Random random = new Random();

	public static String generatePassword() {
		int x = random.nextInt(6);
		System.out.println("x=" + x);
		switch (x) {
		case 0:
			return shapeWords[random.nextInt(shapeWords.length)] + colorWords[random.nextInt(colorWords.length)]
					+ fruitWords[random.nextInt(fruitWords.length)];
		case 1:
			return shapeWords[random.nextInt(shapeWords.length)] + fruitWords[random.nextInt(fruitWords.length)]
					+ colorWords[random.nextInt(colorWords.length)];
		case 2:
			return colorWords[random.nextInt(colorWords.length)] + shapeWords[random.nextInt(shapeWords.length)]
					+ fruitWords[random.nextInt(fruitWords.length)];
		case 3:
			return colorWords[random.nextInt(colorWords.length)] + fruitWords[random.nextInt(fruitWords.length)]
					+ shapeWords[random.nextInt(shapeWords.length)];
		case 4:
			return fruitWords[random.nextInt(fruitWords.length)] + colorWords[random.nextInt(colorWords.length)]
					+ shapeWords[random.nextInt(shapeWords.length)];
		case 5:
			return fruitWords[random.nextInt(fruitWords.length)] + shapeWords[random.nextInt(shapeWords.length)]
					+ colorWords[random.nextInt(colorWords.length)];
		default:
			return shapeWords[random.nextInt(shapeWords.length)] + colorWords[random.nextInt(colorWords.length)]
					+ fruitWords[random.nextInt(fruitWords.length)];
		}
	}

	public static void main(String... arg) {
		for (int i = 0; i < 100; i++) {
			System.out.println(generatePassword());
		}
	}
}
