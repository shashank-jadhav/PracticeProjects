package com.tpoint.base.security.facade;



import org.springframework.security.core.Authentication;

import com.tpoint.base.security.domain.SecurityUserDetails;

public interface AuthenticationFacade {

	Authentication getAuthentication();

	SecurityUserDetails getSecurityUserDetails();

	void clearCurrentAuthenticationCotext();
}
