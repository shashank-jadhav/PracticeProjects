package com.tpoint.base.common.enums;



public enum UserSex {
	
	MALE, FEMALE,UNKNOWN;

}
