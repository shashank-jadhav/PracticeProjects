package com.tpoint.base.security.domain;



public enum AuthProvider {
	AUP_APPLICATION,
	AUP_FACEBOOK;
}
