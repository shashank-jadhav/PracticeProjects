package com.tpoint.base.common.utils;



/**
 * -----------------------------------------------------------------------------
 * <br>
 * <b>Purpose:</b>
 * <p>
 * The purpose of this class is to define widely used constants. Only add
 * constants that are to be used across the project spectrum. All members of
 * this class are immutable. To avoid callers from instantiating the class, a
 * private constructor is used to enforce that policy.
 * </p>
 * -----------------------------------------------------------------------------
 * <br>
 * <b>Implementation:</b>
 * <p>
 * The caller must refer to these constants using static references, such as
 * </p>
 * <blockquote><code>Constants.SUCCESS, Consts.FAILURE,</code> and so on.<br>
 * </blockquote>
 * <p>
 * The members of this class qualify for a static import such as
 * </p>
 * <blockquote><code>import static {package-name}.Constants.SUCCESS;</code><br>
 * </blockquote>
 * 
 * -----------------------------------------------------------------------------
 * 
 * @author Shashank Jadhav
 */
public final class ActivemqConstants {

	/**
	 * Private Constructor to avoid other classes from instantiating this class.
	 */
	private ActivemqConstants() {
		throw new UnsupportedOperationException();
	}

	// Constants-----------------------------------------------------------------------------

	/**
	 * ActiveMQ Produced msg type identifier key
	 */
	public static final String KEY_REG_MSG_TYPE = "REG_MSG_TYPE";

	public static final String KEY_USER_EMAIL = "KEY_USER_EMAIL";

	public static final String KEY_ACTIVATION_LINK = "KEY_ACTIVATION_LINK";

	public static final String VALUE_SEND_USER_ACCOUNT_VERIFICATION_EMAIL = "VALUE_SEND_USER_ACCOUNT_VERIFICATION_EMAIL";

	public static final String VALUE_SEND_FORGOT_PWD_EMAIL = "VALUE_SEND_FORGOT_PWD_EMAIL";

}