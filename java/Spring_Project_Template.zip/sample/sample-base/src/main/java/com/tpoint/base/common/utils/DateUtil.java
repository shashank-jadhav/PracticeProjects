package com.tpoint.base.common.utils;



import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Date;

public final class DateUtil {

	private DateUtil() {
		throw new UnsupportedOperationException();
	}

	private static final DateFormat df = new SimpleDateFormat("dd-MM-yyyy");

	private static final DateTimeFormatter prettyDateTime = DateTimeFormatter.ofPattern("E, dd MMM yyyy hh:mm:ss a z");

	private static final DateTimeFormatter ldtFormatter = DateTimeFormatter.ofPattern("dd-MM-yyyy H:mm");

	private static final DateTimeFormatter ddmmyyyyDateformatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");

	public static Long getCurrentMillis() {
		return System.currentTimeMillis();
	}

	public static LocalDateTime getLocalDateTime() {
		LocalDateTime currentLdt = LocalDateTime.now();
		return currentLdt;
	}

	public static ZonedDateTime getSystemDefaultZonedDateTime(LocalDateTime ldt) {
		ZonedDateTime zdt = ldt.atZone(ZoneId.systemDefault());
		return zdt;
	}

	public static ZonedDateTime getZonedDateTime(LocalDateTime ldt, String timezone) {
		ZonedDateTime zdt = ldt.atZone(ZoneId.of(timezone));
		return zdt;
	}

	public static LocalDateTime parseToLocalDateTime(String dateTime) {
		return LocalDateTime.parse(dateTime, ldtFormatter);
	}

	public static ZonedDateTime getLondonZonedDateTimeFromString(String dateTime) {
		return getZonedDateTime(parseToLocalDateTime(dateTime), "Europe/London");
	}

	public static String getFormattedZonedDateTime(ZonedDateTime zdt) {
		return prettyDateTime.format(zdt);
	}

	public static String getStringFromDate(Date date) {
		return df.format(date);
	}

	public static String getddMMyyyyFormattedDate(LocalDate localDate) {
		return ddmmyyyyDateformatter.format(localDate);
	}
}
