package com.tpoint.auth.custom.dto;



import java.io.Serializable;

public class LoginSuccessResponse implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -955313357369346482L;


	public LoginSuccessResponse() {}
	

	private Long userId;
	private String userName;
	private String displayName;
	private String role;
	private String authProvider;


	public Long getUserId() {
		return userId;
	}
	public void setUserId(Long userId) {
		this.userId = userId;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getDisplayName() {
		return displayName;
	}
	public void setDisplayName(String displayName) {
		this.displayName = displayName;
	}
	public String getRole() {
		return role;
	}
	public void setRole(String role) {
		this.role = role;
	}
	public String getAuthProvider() {
		return authProvider;
	}
	public void setAuthProvider(String authProvider) {
		this.authProvider = authProvider;
	}
	
	
	
}
