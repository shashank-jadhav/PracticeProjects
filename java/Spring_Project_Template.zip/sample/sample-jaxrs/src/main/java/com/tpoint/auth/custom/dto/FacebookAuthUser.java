package com.tpoint.auth.custom.dto;


import java.util.Date;

public class FacebookAuthUser {

	private final String id;
	private final String name;
	private final String email;
	private final String picture;
	private final Date birthday;

	public FacebookAuthUser(String id, String name, String email) {
		this.id = id;
		this.name = name;
		this.email = email;
		this.picture = null;
		this.birthday = null;
	}

	public FacebookAuthUser(String id, String name, String email, String picture, Date birthday) {
		this.id = id;
		this.name = name;
		this.email = email;
		this.picture = picture;
		this.birthday = birthday;
	}

	public String getId() {
		return id;
	}

	public String getName() {
		return name;
	}

	public String getEmail() {
		return email;
	}

	public String getPicture() {
		return picture;
	}

	public Date getBirthday() {
		return birthday;
	}

}
