package com.tpoint.common.jaxrs;



import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;


@Path("common/p/")
public interface CommonAuthJaxrs {

	/**
	 * Functionality for a NHS user (referrer+clinician) to submit a message to
	 * the group chats he is allowed to send a message in.
	 */
	@Path("hhh")
	@GET	
	@Consumes(value = { MediaType.APPLICATION_JSON })
	@Produces(value = { MediaType.APPLICATION_JSON })
	Response addEmergencyConversationMessage();

}
