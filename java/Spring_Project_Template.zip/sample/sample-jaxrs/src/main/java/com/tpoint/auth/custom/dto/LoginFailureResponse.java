package com.tpoint.auth.custom.dto;


import java.io.Serializable;

public class LoginFailureResponse  implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 838456177496021672L;

	public LoginFailureResponse() {}
	
	private DomainSpecificStatus domainSpecificStatus;
	private String errorMessage;

	public DomainSpecificStatus getDomainSpecificStatus() {
		return domainSpecificStatus;
	}

	public void setDomainSpecificStatus(DomainSpecificStatus domainSpecificStatus) {
		this.domainSpecificStatus = domainSpecificStatus;
	}

	public String getErrorMessage() {
		return errorMessage;
	}

	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}

}
