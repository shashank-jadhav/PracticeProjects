package com.tpoint.auth.custom.dto;



public enum DomainSpecificStatus {
	ACCOUNT_INACTIVE,
	ACCOUNT_BANNED,
	USERNAME_NOT_FOUND,
	SESSION_EXPIRED;
}
