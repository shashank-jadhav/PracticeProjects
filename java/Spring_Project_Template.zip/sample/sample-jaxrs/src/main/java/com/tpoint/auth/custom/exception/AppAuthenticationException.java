package com.tpoint.auth.custom.exception;



import org.springframework.security.core.AuthenticationException;

public class AppAuthenticationException extends AuthenticationException {

	private static final long serialVersionUID = 1L;

	private static final String MESSAGE_FORMAT = "AppAuthenticationException: '%s'";

	public AppAuthenticationException(String msg) {
		super(String.format(MESSAGE_FORMAT, msg));
	}

}
