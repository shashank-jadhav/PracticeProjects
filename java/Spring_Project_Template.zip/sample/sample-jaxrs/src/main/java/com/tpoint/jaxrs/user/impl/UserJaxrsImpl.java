package com.tpoint.jaxrs.user.impl;

import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import com.tpoint.core.user.request.dto.UserForgotPasswordRequest;
import com.tpoint.jaxrs.user.UserJaxrs;
import com.tpoint.service.user.UserService;


public class UserJaxrsImpl implements UserJaxrs {

	Logger logger = LoggerFactory.getLogger(UserJaxrsImpl.class);

	@Autowired
	private UserService userService;

	/**
	 * {@inheritDoc}
	 */
	@Override
	public Response findUserByUserName(String userName) {
		try {
			return Response.ok()
					.entity(userService.findUserByUserName(userName))
					.type(MediaType.APPLICATION_JSON).build();
		} catch (Throwable t) {
			t.printStackTrace();
			return Response.serverError().build();
		}
	}

	@Override
	public Response userForgotPassword(UserForgotPasswordRequest req) {
		// TODO Auto-generated method stub
		return null;
	}


}
