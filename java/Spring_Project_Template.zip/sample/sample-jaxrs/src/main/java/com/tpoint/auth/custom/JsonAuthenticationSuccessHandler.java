package com.tpoint.auth.custom;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.security.authentication.AuthenticationServiceException;
import org.springframework.security.core.Authentication;
import org.springframework.security.web.authentication.AuthenticationSuccessHandler;

import com.tpoint.auth.custom.dto.LoginSuccessResponse;
import com.tpoint.base.security.domain.SecurityUserDetails;

public class JsonAuthenticationSuccessHandler implements AuthenticationSuccessHandler {

	public JsonAuthenticationSuccessHandler() {
	}

	public void onAuthenticationSuccess(HttpServletRequest request, HttpServletResponse response,
			Authentication authentication) throws IOException, ServletException, AuthenticationServiceException {

		LoginSuccessResponse loginSuccessResponse = new LoginSuccessResponse();

		Object principal = authentication.getPrincipal();
		// get the details from authentication and put into loginResponse.

		if (principal instanceof SecurityUserDetails) {
			SecurityUserDetails securityUserDetails = (SecurityUserDetails) principal;
			loginSuccessResponse.setUserName(securityUserDetails.getUserName());
			loginSuccessResponse.setRole(securityUserDetails.getRole());
			loginSuccessResponse.setUserId(securityUserDetails.getUserId());
			loginSuccessResponse.setAuthProvider(securityUserDetails.getAuthProvider());
	
			try {
				response.setContentType("application/json");
				response.setStatus(HttpServletResponse.SC_OK);
				JsonAuthenticationResponseWriterUtil.writeJsonModelToHttpServletResponse(response,
						loginSuccessResponse);
			} catch (AuthenticationServiceException e) {
				request.getSession().invalidate();
				response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, e.getMessage());
			}
		}
	}
}
