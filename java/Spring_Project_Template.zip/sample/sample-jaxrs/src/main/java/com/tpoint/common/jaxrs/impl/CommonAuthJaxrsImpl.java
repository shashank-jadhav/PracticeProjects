package com.tpoint.common.jaxrs.impl;


import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.tpoint.common.jaxrs.CommonAuthJaxrs;

public class CommonAuthJaxrsImpl implements CommonAuthJaxrs {

	Logger logger = LoggerFactory.getLogger(CommonAuthJaxrsImpl.class);

	

	/**
	 * {@inheritDoc}
	 */

	public Response addEmergencyConversationMessage() {
		try {
			return Response.ok()
				
					.type(MediaType.APPLICATION_JSON).build();
		} catch (Throwable t) {
			t.printStackTrace();
			return Response.serverError().build();
		}
	}

	
}
