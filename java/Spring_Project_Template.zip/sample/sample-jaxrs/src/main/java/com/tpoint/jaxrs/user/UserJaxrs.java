package com.tpoint.jaxrs.user;

import javax.validation.Valid;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.hibernate.validator.constraints.NotBlank;

import com.tpoint.core.user.request.dto.UserForgotPasswordRequest;

@Path("tp/user/")
public interface UserJaxrs {

	
/**
 * Used to reset password
 * @param req
 * @return
 */
	@Path("forgot-pwd")
	@PUT
	@Consumes(value = { MediaType.APPLICATION_JSON })
	@Produces(value = { MediaType.APPLICATION_JSON })
	Response userForgotPassword(@Valid UserForgotPasswordRequest req);
	
	
	/**
	 * Used to find user by its tipping name
	 * @param tippingName
	 * @return User
	 */
	
	@Path("find-user-by-tipping-name")
	@GET
	@Produces(value = { MediaType.APPLICATION_JSON })
	Response findUserByUserName(@QueryParam("userName") @NotBlank String userName);

	
}
