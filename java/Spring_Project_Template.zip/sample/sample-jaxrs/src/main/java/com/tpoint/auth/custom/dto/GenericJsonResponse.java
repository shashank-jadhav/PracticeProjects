package com.tpoint.auth.custom.dto;



import java.io.Serializable;

public class GenericJsonResponse implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -3216385258186503183L;

	private DomainSpecificStatus domainSpecificStaus;
	private String message;

	public GenericJsonResponse(DomainSpecificStatus domainSpecificStaus, String message) {
		this.domainSpecificStaus = domainSpecificStaus;
		this.message = message;
	}

	public DomainSpecificStatus getDomainSpecificStaus() {
		return domainSpecificStaus;
	}

	public void setDomainSpecificStaus(DomainSpecificStatus domainSpecificStaus) {
		this.domainSpecificStaus = domainSpecificStaus;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

}
