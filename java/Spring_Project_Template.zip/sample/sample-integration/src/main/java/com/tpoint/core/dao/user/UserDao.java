package com.tpoint.core.dao.user;

import com.tpoint.core.dao.common.CommonOperations;
import com.tpoint.hib.model.user.User;


public interface UserDao extends CommonOperations<User> {
	
	User findUserByUserName(String userName);

}
