package com.tpoint.core.dao.common;

import java.io.Serializable;

public interface CommonDao<T extends Serializable> extends CommonOperations<T> {

}
