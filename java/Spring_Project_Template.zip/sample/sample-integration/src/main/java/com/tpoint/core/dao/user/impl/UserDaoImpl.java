package com.tpoint.core.dao.user.impl;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.Assert;

import com.tpoint.core.dao.common.AbstractCommonOperationsDaoImpl;
import com.tpoint.core.dao.user.UserDao;
import com.tpoint.hib.model.user.User;


@Repository
@Transactional(propagation = Propagation.MANDATORY)
public class UserDaoImpl extends AbstractCommonOperationsDaoImpl<User> implements UserDao {

	Logger logger = LoggerFactory.getLogger(UserDaoImpl.class);

	public UserDaoImpl() {
		super();
		setClazz(User.class);
	}

	@Override
	public User findUserByUserName(String userName) {
		Assert.hasText(userName);
		return (User) getCurrentSession().getNamedQuery("FIND_USER_BY_USERNAME")
				.setParameter("suppliedUserName", userName).uniqueResult();
	}

}
