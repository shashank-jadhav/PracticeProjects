package com.sample.core.dao.user;

import com.sample.core.dao.common.CommonOperations;
import com.sample.hib.model.user.UserVerificationScope;

public interface UserVerificationScopeDao extends CommonOperations<UserVerificationScope> {

}
