package com.sample.hib.config;




import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Embeddable;

@Embeddable
public class UserVerificationCodePK implements Serializable {

	private static final long serialVersionUID = 1L;

	@Column(name = "user_id")
	private Long userId;

	@Column(name = "verification_scope")
	private String verificationScope;

	public UserVerificationCodePK() {
		super();
	}

	public UserVerificationCodePK(Long userId, String verificationScope) {
		super();
		this.userId = userId;
		this.verificationScope = verificationScope;
	}

	public Long getUserId() {
		return userId;
	}

	public void setUserId(Long userId) {
		this.userId = userId;
	}

	public String getVerificationScope() {
		return verificationScope;
	}

	public void setVerificationScope(String verificationScope) {
		this.verificationScope = verificationScope;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((userId == null) ? 0 : userId.hashCode());
		result = prime * result + ((verificationScope == null) ? 0 : verificationScope.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		UserVerificationCodePK other = (UserVerificationCodePK) obj;
		if (userId == null) {
			if (other.userId != null)
				return false;
		} else if (!userId.equals(other.userId))
			return false;
		if (verificationScope == null) {
			if (other.verificationScope != null)
				return false;
		} else if (!verificationScope.equals(other.verificationScope))
			return false;
		return true;
	}

}
