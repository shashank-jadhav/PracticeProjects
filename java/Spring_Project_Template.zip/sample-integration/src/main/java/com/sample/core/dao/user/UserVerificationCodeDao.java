package com.sample.core.dao.user;

import com.sample.core.dao.common.CommonOperations;
import com.sample.hib.model.user.UserVerificationCode;

public interface UserVerificationCodeDao extends CommonOperations<UserVerificationCode> {

}
