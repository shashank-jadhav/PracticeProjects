package com.sample.core.dao.user;

import java.util.List;

import com.sample.core.dao.common.CommonOperations;
import com.sample.hib.model.user.User;


public interface UserDao extends CommonOperations<User> {
	
	User findUserByUserName(String userName);
	
	List<String> findUserNameByEmail(String email);

}
