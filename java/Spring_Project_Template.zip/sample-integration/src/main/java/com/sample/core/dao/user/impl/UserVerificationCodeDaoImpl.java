package com.sample.core.dao.user.impl;



import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.sample.core.dao.common.AbstractCommonOperationsDaoImpl;
import com.sample.core.dao.user.UserVerificationCodeDao;
import com.sample.hib.model.user.UserVerificationCode;

@Repository
@Transactional(propagation = Propagation.MANDATORY)
public class UserVerificationCodeDaoImpl extends AbstractCommonOperationsDaoImpl<UserVerificationCode>
		implements UserVerificationCodeDao {

	Logger logger = LoggerFactory.getLogger(UserVerificationCodeDaoImpl.class);

	public UserVerificationCodeDaoImpl() {
		super();
		setClazz(UserVerificationCode.class);
	}

}
