package com.sample.hib.model.user;



import java.io.Serializable;
import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Version;

import com.sample.hib.config.UserVerificationCodePK;

@Entity
@Table(name = "user_verification_code", catalog = "tpoint")
public class UserVerificationCode implements Serializable {

	private static final long serialVersionUID = 1L;

	@EmbeddedId
	private UserVerificationCodePK VCPK;

	@ManyToOne(targetEntity = User.class, fetch = FetchType.LAZY)
	@JoinColumn(nullable = false, name = "user_id", updatable = false, insertable = false)
	private User user;

	@ManyToOne(targetEntity = UserVerificationScope.class, fetch = FetchType.LAZY)
	@JoinColumn(nullable = false, name = "verification_scope", updatable = false, insertable = false)
	private UserVerificationScope userVerificationScope;

	@Column(name = "verification_code")
	private String verificationCode;

	@Column(name = "code_request_datetime")
	private LocalDateTime codeRequestDateTime;

	@Column(name = "code_request_timezone")
	private String codeRequestTimezone;

	@Column(name = "code_request_millis_since_epoch")
	private Long codeRequestMillis;

	@Column(name = "code_expiration_datetime")
	private LocalDateTime codeExpirationDateTime;

	@Column(name = "code_expiration_timezone")
	private String codeExpirationTimezone;

	@Column(name = "code_expiration_millis_since_epoch")
	private Long codeExpirationMillis;

	@Version
	@Column(name = "record_version")
	private Long recordVersion;

	public UserVerificationCodePK getVCPK() {
		return VCPK;
	}

	public void setVCPK(UserVerificationCodePK vCPK) {
		VCPK = vCPK;
	}

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	public UserVerificationScope getUserVerificationScope() {
		return userVerificationScope;
	}

	public void setUserVerificationScope(UserVerificationScope userVerificationScope) {
		this.userVerificationScope = userVerificationScope;
	}

	public LocalDateTime getCodeRequestDateTime() {
		return codeRequestDateTime;
	}

	public void setCodeRequestDateTime(LocalDateTime codeRequestDateTime) {
		this.codeRequestDateTime = codeRequestDateTime;
	}

	public String getCodeRequestTimezone() {
		return codeRequestTimezone;
	}

	public void setCodeRequestTimezone(String codeRequestTimezone) {
		this.codeRequestTimezone = codeRequestTimezone;
	}

	public Long getCodeRequestMillis() {
		return codeRequestMillis;
	}

	public void setCodeRequestMillis(Long codeRequestMillis) {
		this.codeRequestMillis = codeRequestMillis;
	}

	public LocalDateTime getCodeExpirationDateTime() {
		return codeExpirationDateTime;
	}

	public void setCodeExpirationDateTime(LocalDateTime codeExpirationDateTime) {
		this.codeExpirationDateTime = codeExpirationDateTime;
	}

	public String getCodeExpirationTimezone() {
		return codeExpirationTimezone;
	}

	public void setCodeExpirationTimezone(String codeExpirationTimezone) {
		this.codeExpirationTimezone = codeExpirationTimezone;
	}

	public Long getCodeExpirationMillis() {
		return codeExpirationMillis;
	}

	public void setCodeExpirationMillis(Long codeExpirationMillis) {
		this.codeExpirationMillis = codeExpirationMillis;
	}

	public Long getRecordVersion() {
		return recordVersion;
	}

	public void setRecordVersion(Long recordVersion) {
		this.recordVersion = recordVersion;
	}

	public String getVerificationCode() {
		return verificationCode;
	}

	public void setVerificationCode(String verificationCode) {
		this.verificationCode = verificationCode;
	}

}
