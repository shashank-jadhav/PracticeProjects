package com.sample.hib.model.user;



import java.io.Serializable;
import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

@Entity
@Table(name = "user_verification_scope", catalog = "tpoint")
public class UserVerificationScope implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	@Column(name = "verification_scope")
	private String verificationScope;

	@Column(name = "description")
	private String description;

	@CreationTimestamp
	@Column(name = "create_timestamp")
	private LocalDateTime createTimestamp;

	@UpdateTimestamp
	@Column(name = "update_timestamp")
	private LocalDateTime updateTimestamp;

	public String getVerificationScope() {
		return verificationScope;
	}

	public void setVerificationScope(String verificationScope) {
		this.verificationScope = verificationScope;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public LocalDateTime getCreateTimestamp() {
		return createTimestamp;
	}

	public void setCreateTimestamp(LocalDateTime createTimestamp) {
		this.createTimestamp = createTimestamp;
	}

	public LocalDateTime getUpdateTimestamp() {
		return updateTimestamp;
	}

	public void setUpdateTimestamp(LocalDateTime updateTimestamp) {
		this.updateTimestamp = updateTimestamp;
	}

}
