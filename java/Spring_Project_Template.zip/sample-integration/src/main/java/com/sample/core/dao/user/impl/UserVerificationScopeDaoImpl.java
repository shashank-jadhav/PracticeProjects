package com.sample.core.dao.user.impl;



import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.sample.core.dao.common.AbstractCommonOperationsDaoImpl;
import com.sample.core.dao.user.UserVerificationScopeDao;
import com.sample.hib.model.user.UserVerificationScope;

@Repository
@Transactional(propagation = Propagation.MANDATORY)
public class UserVerificationScopeDaoImpl extends AbstractCommonOperationsDaoImpl<UserVerificationScope>
		implements UserVerificationScopeDao {

	Logger logger = LoggerFactory.getLogger(UserVerificationScopeDaoImpl.class);

	public UserVerificationScopeDaoImpl() {
		super();
		setClazz(UserVerificationScope.class);
	}

}
