package com.sample.hib.model.user;

import java.io.Serializable;
import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.Filter;
import org.hibernate.annotations.FilterDef;
import org.hibernate.annotations.ParamDef;
import org.hibernate.annotations.UpdateTimestamp;



@Entity
@FilterDef(name = "filterDeleted", parameters = @ParamDef(name = "suppliedIsDeleted", type = "boolean"))
@Filter(name = "filterDeleted", condition = ":suppliedIsDeleted = is_deleted")
@Table(name = "tp_users", catalog = "tpoint")
public class User implements Serializable {

	private static final long serialVersionUID = 4642864878613368990L;

	@Id
	@GeneratedValue
	@Column(name = "user_id")
	private Long userId;


	@Column(name = "user_name")
	private String userName;

	
	@Column(name = "tipping_name")
	private String tippingName;

	@Column(name = "password_hash")
	private String passwordHash;

	@Column(name = "role")
	private String role;

	@Column(name = "account_status")
	private String accountStatus;

	@Column(name = "is_user_logged_in")
	private boolean userLoggedIn;

	@Column(name = "last_login_timestamp")
	private LocalDateTime lastLoginTimestamp;
	@Column(name = "last_login_millis_since_epoch")
	private Long lastLoginMillis;
	@Column(name = "last_login_timezone")
	private String lastLoginTimezone;

	@Column(name = "is_profile_updated")
	private boolean profileUpdated;

	@Column(name = "last_logout_timestamp")
	private LocalDateTime lastLogoutTimestamp;
	@Column(name = "last_logout_millis_since_epoch")
	private Long lastLogoutMillis;
	@Column(name = "last_logout_timezone")
	private String lastLogoutTimezone;

	@Column(name = "is_auto_gen_password_changed")
	private boolean autoGenPasswordChanged;

	@Column(name = "pass_change_timestamp")
	private LocalDateTime passwordChangeTimestamp;
	@Column(name = "pass_change_millis_since_epoch")
	private Long passwordChangeMillis;
	@Column(name = "pass_change_timezone")
	private String passwordChangeTimezone;

	@Column(name = "email_address")
	private String emailAddress;

	@Column(name = "mobile_number")
	private String mobileNumber;

	@Column(name = "auth_provider")
	private String authProvider;

	@Column(name = "is_banned")
	private boolean banned;

	@Column(name = "ban_reason")
	private String banReason;

	@Column(name = "banned_timestamp")
	private LocalDateTime bannedTimestamp;

	@Column(name = "banning_admin_user_uri")
	private String banningAdminUserUri;

	@CreationTimestamp
	@Column(name = "creation_timestamp")
	private LocalDateTime creationTimestamp;

	@UpdateTimestamp
	@Column(name = "update_timestamp")
	private LocalDateTime updateTimestamp;

	@Column(name = "is_deleted")
	private boolean deleted;

	public Long getUserId() {
		return userId;
	}

	public void setUserId(Long userId) {
		this.userId = userId;
	}

	
	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getTippingName() {
		return tippingName;
	}

	public void setTippingName(String tippingName) {
		this.tippingName = tippingName;
	}

	public boolean isProfileUpdated() {
		return profileUpdated;
	}

	public void setProfileUpdated(boolean profileUpdated) {
		this.profileUpdated = profileUpdated;
	}

	public String getPasswordHash() {
		return passwordHash;
	}

	public void setPasswordHash(String passwordHash) {
		this.passwordHash = passwordHash;
	}

	public String getRole() {
		return role;
	}

	public void setRole(String role) {
		this.role = role;
	}

	public boolean isUserLoggedIn() {
		return userLoggedIn;
	}

	public void setUserLoggedIn(boolean userLoggedIn) {
		this.userLoggedIn = userLoggedIn;
	}

	public boolean isAutoGenPasswordChanged() {
		return autoGenPasswordChanged;
	}

	public void setAutoGenPasswordChanged(boolean autoGenPasswordChanged) {
		this.autoGenPasswordChanged = autoGenPasswordChanged;
	}

	public LocalDateTime getPasswordChangeTimestamp() {
		return passwordChangeTimestamp;
	}

	public void setPasswordChangeTimestamp(LocalDateTime passwordChangeTimestamp) {
		this.passwordChangeTimestamp = passwordChangeTimestamp;
	}

	public String getEmailAddress() {
		return emailAddress;
	}

	public void setEmailAddress(String emailAddress) {
		this.emailAddress = emailAddress;
	}

	public String getMobileNumber() {
		return mobileNumber;
	}

	public String getAuthProvider() {
		return authProvider;
	}

	public void setAuthProvider(String authProvider) {
		this.authProvider = authProvider;
	}

	public void setMobileNumber(String mobileNumber) {
		this.mobileNumber = mobileNumber;
	}

	public boolean isBanned() {
		return banned;
	}

	public void setBanned(boolean banned) {
		this.banned = banned;
	}

	public String getBanReason() {
		return banReason;
	}

	public void setBanReason(String banReason) {
		this.banReason = banReason;
	}

	public LocalDateTime getBannedTimestamp() {
		return bannedTimestamp;
	}

	public void setBannedTimestamp(LocalDateTime bannedTimestamp) {
		this.bannedTimestamp = bannedTimestamp;
	}

	public String getBanningAdminUserUri() {
		return banningAdminUserUri;
	}

	public void setBanningAdminUserUri(String banningAdminUserUri) {
		this.banningAdminUserUri = banningAdminUserUri;
	}

	public LocalDateTime getCreationTimestamp() {
		return creationTimestamp;
	}

	public void setCreationTimestamp(LocalDateTime creationTimestamp) {
		this.creationTimestamp = creationTimestamp;
	}

	public LocalDateTime getUpdateTimestamp() {
		return updateTimestamp;
	}

	public void setUpdateTimestamp(LocalDateTime updateTimestamp) {
		this.updateTimestamp = updateTimestamp;
	}

	public boolean isDeleted() {
		return deleted;
	}

	public void setDeleted(boolean deleted) {
		this.deleted = deleted;
	}


	public String getAccountStatus() {
		return accountStatus;
	}

	public void setAccountStatus(String accountStatus) {
		this.accountStatus = accountStatus;
	}

	public LocalDateTime getLastLoginTimestamp() {
		return lastLoginTimestamp;
	}

	public void setLastLoginTimestamp(LocalDateTime lastLoginTimestamp) {
		this.lastLoginTimestamp = lastLoginTimestamp;
	}

	public Long getLastLoginMillis() {
		return lastLoginMillis;
	}

	public void setLastLoginMillis(Long lastLoginMillis) {
		this.lastLoginMillis = lastLoginMillis;
	}

	public String getLastLoginTimezone() {
		return lastLoginTimezone;
	}

	public void setLastLoginTimezone(String lastLoginTimezone) {
		this.lastLoginTimezone = lastLoginTimezone;
	}

	public LocalDateTime getLastLogoutTimestamp() {
		return lastLogoutTimestamp;
	}

	public void setLastLogoutTimestamp(LocalDateTime lastLogoutTimestamp) {
		this.lastLogoutTimestamp = lastLogoutTimestamp;
	}

	public Long getLastLogoutMillis() {
		return lastLogoutMillis;
	}

	public void setLastLogoutMillis(Long lastLogoutMillis) {
		this.lastLogoutMillis = lastLogoutMillis;
	}

	public String getLastLogoutTimezone() {
		return lastLogoutTimezone;
	}

	public void setLastLogoutTimezone(String lastLogoutTimezone) {
		this.lastLogoutTimezone = lastLogoutTimezone;
	}

	public Long getPasswordChangeMillis() {
		return passwordChangeMillis;
	}

	public void setPasswordChangeMillis(Long passwordChangeMillis) {
		this.passwordChangeMillis = passwordChangeMillis;
	}

	public String getPasswordChangeTimezone() {
		return passwordChangeTimezone;
	}

	public void setPasswordChangeTimezone(String passwordChangeTimezone) {
		this.passwordChangeTimezone = passwordChangeTimezone;
	}

}
