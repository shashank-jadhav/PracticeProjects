package com.sample.core.dao.user.impl;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.Assert;

import com.sample.core.dao.common.AbstractCommonOperationsDaoImpl;
import com.sample.core.dao.user.UserDao;
import com.sample.hib.model.user.User;

@Repository
@Transactional(propagation = Propagation.MANDATORY)
public class UserDaoImpl extends AbstractCommonOperationsDaoImpl<User> implements UserDao {

	Logger logger = LoggerFactory.getLogger(UserDaoImpl.class);

	public UserDaoImpl() {
		super();
		setClazz(User.class);
	}

	@Override
	public User findUserByUserName(String userName) {
		Assert.hasText(userName);
		return (User) getCurrentSession().getNamedQuery("FIND_USER_BY_USERNAME")
				.setParameter("suppliedUserName", userName).uniqueResult();
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<String> findUserNameByEmail(String email) {
		Assert.hasText(email);
		return (List<String>) getCurrentSession().getNamedQuery("FIND_USERNAME_BY_EMAIL")
				.setParameter("suppliedEmail", email).list();
	}

}
