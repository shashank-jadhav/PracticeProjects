
/******************************************************************************
 * Module Id/Name   : com.tpoint.hib.config
 * File Name        : StringSequenceIdentifier.java
 * Purpose          : 
 * Copy Right       :  2017 - 2018 nWorks Technologies. All Rights Reserved. (http://nworks.co/)
 * Version  Date         Created By             
 * 1.00     Feb 2, 2018   sagar.tarle           
 *******************************************************************************/
package com.sample.hib.config;

import java.io.Serializable;
import java.util.UUID;

import org.hibernate.HibernateException;
import org.hibernate.engine.spi.SharedSessionContractImplementor;
import org.hibernate.id.IdentifierGenerator;

public class StringSequenceIdentifier implements IdentifierGenerator {

	@Override
	public Serializable generate(SharedSessionContractImplementor arg0, Object arg1) throws HibernateException {
		return UUID.randomUUID().toString().replace("-", "");
	}

}
