package com.sample.base.security.facade;



import org.springframework.security.core.Authentication;

import com.sample.base.security.domain.SecurityUserDetails;

public interface AuthenticationFacade {

	Authentication getAuthentication();

	SecurityUserDetails getSecurityUserDetails();

	void clearCurrentAuthenticationCotext();
}
