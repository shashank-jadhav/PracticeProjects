package com.sample.base.security.domain;



public enum Platform {
	PLATFORM_ANDROID,
	PLATFORM_IOS,
	PLATFORM_WINDOWS;
}
