package com.sample.base.common.enums;



public enum Results {

	/**
	 * Related to Login functionality.
	 */
	LoginSuccess("User has been granted a session."),
	UserRegisteredSuccessfully("User Registered sucessfully."),
	ProfileFetchSuccess("User will get the details of his/her profile."),
	UserUpdatedSuccessfully("User profile updated successfully"),
	PasswordChangedSuccessfully("Password has been changed."),
	PasswordResetSuccessfully("Password reset sucessfully password is sent to user's registered email id."),
	UsernameFetchedSuccessfully("Tipping name list"),
	InvitationMailSentSuccessfully("Invitation mail sent Successfully"),
	TippingNameList("Your tipping name has been sent to your email address. Please check your email in a few minutes"),
	CompCreatedSuccessfully("Competition created successfully"),
	
	Other("");
	;

	String description;

	private Results(String description) {
		this.description = description;
	}

	public String getDescription() {
		return description;
	}

	public String getMessage() {
		return description;
	}

}
