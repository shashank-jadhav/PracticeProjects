package com.sample.base.security.exception;



import org.springframework.security.core.AuthenticationException;

public class AuthenticationFacadeException extends AuthenticationException {

	private static final long serialVersionUID = -2984806812560730741L;

	private static final String MESSAGE_FORMAT = "AuthenticationFacadeException: '%s'";

	public AuthenticationFacadeException(String msg) {
		super(String.format(MESSAGE_FORMAT, msg));
	}

}
