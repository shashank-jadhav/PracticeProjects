package com.sample.base.security.domain;



public enum Role {
	ROLE_MANAGER_USER,
	ROLE_NORMAL_USER;
}
