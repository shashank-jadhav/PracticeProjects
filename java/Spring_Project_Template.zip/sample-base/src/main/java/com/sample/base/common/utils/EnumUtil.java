package com.sample.base.common.utils;

/**
 * Useful enum utilities
 */
public final class EnumUtil {

	public static <T extends Enum<T>> boolean enumContains(Class<T> enumerator, String value)
	{
	    for (T c : enumerator.getEnumConstants()) {
	        if (c.name().equals(value)) {
	            return true;
	        }
	    }
	    return false;
	}
}