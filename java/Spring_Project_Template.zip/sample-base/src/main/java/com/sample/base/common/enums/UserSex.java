package com.sample.base.common.enums;



public enum UserSex {
	
	MALE, FEMALE,UNKNOWN;

}
