package com.sample.base.common.constant;



public final class AppConstants {

	/** Activation link related **/
	public static final String ACTIVATION_CODE_EXPIRATION_IN_MINS = "activationCodeExpirationInMins";
	public static final String ACTIVATION_CODE_EXPIRATION_IN_MINS_DEFAULT = "10";

	public static final String EMAIL_ACTIVATION_CODE_EXPIRATION_IN_MINS = "email.activationCodeExpirationInMins";
	public static final String EMAIL_ACTIVATION_CODE_EXPIRATION_IN_MINS_DEFAULT = "1440";

	public static final String ACTIVATION_LINK_PATH = "activationLinkPath";

	/** Facebook related **/
	public static final String FACEBOOK_APP_SECRET = "facebook.app.secret";
	public static final String FACEBOOK_USER_ID_EMPTY_MSG = "Facebook User ID is empty or null ! Please check the granted permissions on accessToken.";
	public static final String FACEBOOK_EMAIL_ADDRESS_EMPTY_MSG = "Facebook emailAddress is empty or null ! Please check the granted permissions on accessToken.";
	public static final String FACEBOOK_NAME_EMPTY_MSG = "Facebook username or user's real name is empty or null ! Please check the granted permissions on accessToken.";

	public static final String BAD_CREDENTIALS = "Bad credentials !";

	public static final String ACCESS_TOKEN_EMPTY_MSG = "accessToken parameter must not be empty or null.";

	public static final String SINGLE_SPACE = " ";

	public static final String SCHEME_SEPRATOR = "://";

	public static final String WEB_RESOURCE_SEPRATOR = "/";

	public static final String QUESTION_MARK = "?";

	public static final String AMPERSAND = "&";

	public static final String SINGLE_EQUALS = "=";

	public static final String COLON = ":";

	/** String variable to store "." literal */
	public static final String DOT = ".";

	public static final String UNDERSCORE = "_";

	public static final String ENCODING_UTF8 = "UTF-8";

	public static final String UNKNOWN_FILE_NAME = "_unknown";

	public static final String FILE_SEPARATOR = System.getProperty("file.separator");

	/*** Mail Related ***/
	public static final String MAIL_FROM = "mail.from";
	public static final String MAIL_ACTIVATION_SUBJECT = "mail.activation.subject";
	public static final String MAIL_VERIFICATION_SUBJECT = "mail.verification.subject";
	public static final String MAIL_FORGET_PASSWORD_SUBJECT = "mail.forget.password.subject";
	public static final String MAIL_USER_INT_NOTIFICATION_SUBJECT = "mail.user.int.notification.subject";
	public static final String MAIL_WEAK_NOTIFICATION_SUBJECT = "mail.weak.notification.subject";

	/** Activation Related **/
	public static final String ACTIVATION_ID = "emVrfIdentity";
	public static final String ACTIVATION_CODE = "emVrfSuiGenerisCodex";
	public static final String ACTIVATION_LINK = "ALNK";
	public static final String ACTIVATION_EMAIL_ADDRESS = "AMAIL";

	/** Messaging Related for JMS **/
	public static final String KEY_USER_NAME = "UserName";
	public static final String KEY_USER_ID = "UserId";

	/** Registration related for JMS **/
	public static final String KEY_ACTIVATION_CODE = "ActivationCode";
	public static final String KEY_REG_MSG_TYPE = "REG_MSG_TYPE";
	public static final String VALUE_REG_MSG_ACTIVATION = "REG_MSG_ACTIVATION";
	public static final String VALUE_REG_MSG_FORGET_PASSWORD = "REG_MSG_FORGET_PASSWORD";
	public static final String KEY_EMAIL_ADDRESS = "EmailAddress";
	public static final String KEY_DISPLAY_NAME = "DisplayName";
	public static final String KEY_ACTIVATION_LINK = "ActivationLink";
	public static final String VALUE_REG_MSG_ACTIVATION_MAIL = "REG_MSG_ACTIVATION_MAIL";

	/** Notification Related **/
	// Shared keys for all the JMS/PUSH/FTL notification Message properties
	public static final String KEY_NOTIFICATION_TYPE = "NotificationType";
	public static final String KEY_NOTIFICATION_CREATION_PLACE = "NotificationCreationPlace";
	public static final String KEY_COMMENT_ID = "CommentId";
	public static final String KEY_NF_SENDER_USER_ID = "NfSenderUserId";
	public static final String KEY_NOTIFICATION_ID = "NotificationId";
	public static final String KEY_NF_TYPE_RFRNC_ID = "NfTypeRfrncId";
	
	public static final String KEY_NOTIFICATION_TIME = "NotificationTime";
	public static final String KEY_INCIDENT_ID = "IncidentId";
	public static final String KEY_INCIDENT_TITLE = "IncidentTitle";
	public static final String KEY_NF_SENDER_DISPLAY_NAME = "NfSenderDisplayName";
	public static final String KEY_NF_SENDER_DISPLAY_IMAGE = "NfSenderDisplayImage";
	public static final String KEY_NF_RCVR_DISPLAY_NAME = "NfRcvrDisplayName";
	public static final String KEY_NF_COUNT = "NfCount";
	
	public static final String KEY_NF_DESTINATION_USER_ID = "NfDestinationUserId";
	public static final String KEY_NF_DESTINATION_ADDRESS = "NfDestinationAddress";
	public static final String KEY_NF_TEXT_PAYLOAD = "NfTextPayload";
	public static final String KEY_NF_DESTINATION_TYPE = "NfDestinationType";

	// MPNS notification types:
	public static final String MPNS_TILE_MESSAGE = "token";
	public static final String MPNS_TOAST_MESSAGE = "toast";
	public static final String MPNS_RAW_MESSAGE = "raw";
	public static final String USER_WEAK_NOTIFICATION_MESSAGE = "user.weak.notification.message";

	// user settings related
	public static final String USER_DFLT_STTNGS_EMAIL_NF_PRFRNC = "user.default.settings.emailNfPrfrnc";
	public static final String USER_DFLT_STTNGS_PUSH_NF_PRFRNC = "user.default.settings.pushNfPrfrnc";
	public static final String USER_DFLT_STTNGS_EMAIL_NF_FRQNCY_HRS = "user.default.settings.emailNfFrqncy.hrs";
	public static final String USER_DFLT_STTNGS_PUSH_NF_FRQNCY_HRS = "user.default.settings.pushNfFrqncy.hrs";
	public static final String USER_DFLT_STTNGS_DEFAULT_RADIUS = "user.default.settings.radius";
	public static final String DESTINATION_TYPE_EMAIL = "EMAIL";

	public static final int HTTP_STATUS_AUTHENTICATION_TIMEOUT = 419;
	
	public static final char SOH = '\u0001';
}
