package com.sample.base.common.utils;



import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.UUID;

/**
 * Random UUID code generator.
 * 
 */
public class ActivationCodeGenerator {

	/**
	 * Private Constructor to avoid other classes from instantiating this class.
	 */
	private ActivationCodeGenerator() {
		throw new UnsupportedOperationException();
	}

	/**
	 * This method generates a random immutable universally unique identifier
	 * which is hashed using SHA-256.
	 * 
	 * @throws NoSuchAlgorithmException
	 */
	public static String generateCode() {

		try {
			String code = UUID.randomUUID().toString();

			MessageDigest messageDigest;
			messageDigest = MessageDigest.getInstance("SHA-256");
			byte byteData[] = messageDigest.digest(code.getBytes(StandardCharsets.UTF_8));
			return StringUtil.toHex(byteData);
		} catch (NoSuchAlgorithmException e) {
			throw new RuntimeException("Error while genereting code.");
		}
	}
}
