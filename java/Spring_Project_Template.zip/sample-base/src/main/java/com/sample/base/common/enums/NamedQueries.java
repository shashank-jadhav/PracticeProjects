package com.sample.base.common.enums;



public enum NamedQueries {

	FIND_USER_BY_USERNAME("This query will return user with corresponding to supplied email.")
	
	;

	String description;

	private NamedQueries(String description) {
		this.description = description;
	}

	public String getDescription() {
		return description;
	}

	public String getMessage() {
		return description;
	}

}
